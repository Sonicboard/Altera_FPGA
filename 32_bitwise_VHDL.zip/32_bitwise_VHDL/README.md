# Altera_FPGA
알테라 사의 FPGA 프로세서 칩 EP4CE6E22C8이 사용된 개발 보드를 바탕으로 Quartus II Software를 이용, VHDL 언어를 바탕으로 작성됌.
